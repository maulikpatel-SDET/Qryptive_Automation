// Static import: getInstance() with no class name.
package com.qx;
import static java.security.KeyPairGenerator.getInstance;
import java.security.KeyPairGenerator;

public class StaticImportSigner {
    public static void run() throws Exception {
        KeyPairGenerator g = getInstance("RSA");
        g.initialize(2048);
        g.generateKeyPair();
    }
}
