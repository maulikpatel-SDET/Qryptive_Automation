// PQC (BouncyCastle): ML-KEM-768 and ML-DSA-65 - quantum-safe.
package com.qx.pqc;
import java.security.KeyPairGenerator;
import java.security.SecureRandom;
import java.security.Security;
import org.bouncycastle.jcajce.spec.MLDSAParameterSpec;
import org.bouncycastle.jcajce.spec.MLKEMParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class PqcKeys {
    public static void all() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        KeyPairGenerator kem = KeyPairGenerator.getInstance("ML-KEM", "BC");
        kem.initialize(MLKEMParameterSpec.ml_kem_768, new SecureRandom());
        kem.generateKeyPair();
        KeyPairGenerator dsa = KeyPairGenerator.getInstance("ML-DSA", "BC");
        dsa.initialize(MLDSAParameterSpec.ml_dsa_65, new SecureRandom());
        dsa.generateKeyPair();
    }
}
