// Cipher transformations: RSA/OAEP, AES/ECB (weak), DESede, MD5, SHA-1.
package com.qx;
import java.security.MessageDigest;
import javax.crypto.Cipher;

public class Ciphers {
    public static void all() throws Exception {
        Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        Cipher.getInstance("AES/ECB/PKCS5Padding");   // weak mode
        Cipher.getInstance("DESede/CBC/PKCS5Padding"); // 3DES
        MessageDigest.getInstance("MD5");
        MessageDigest.getInstance("SHA-1");
    }
}
