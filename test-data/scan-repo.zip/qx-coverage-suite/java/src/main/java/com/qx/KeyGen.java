// Key generation: RSA, EC, DSA (JDK).
package com.qx;
import java.security.KeyPairGenerator;
import java.security.spec.ECGenParameterSpec;

public class KeyGen {
    public static void all() throws Exception {
        KeyPairGenerator rsa = KeyPairGenerator.getInstance("RSA"); rsa.initialize(2048); rsa.generateKeyPair();
        KeyPairGenerator ec = KeyPairGenerator.getInstance("EC"); ec.initialize(new ECGenParameterSpec("secp256r1")); ec.generateKeyPair();
        KeyPairGenerator dsa = KeyPairGenerator.getInstance("DSA"); dsa.initialize(2048); dsa.generateKeyPair();
    }
}
