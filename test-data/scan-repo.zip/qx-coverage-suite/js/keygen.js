// Node key generation: RSA, EC.
const crypto = require('crypto');
const rsa = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const ec = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
module.exports = { rsa, ec };
