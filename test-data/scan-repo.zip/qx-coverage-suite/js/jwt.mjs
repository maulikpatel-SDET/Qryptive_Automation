// jsonwebtoken: RS256 and HS256.
import jwt from 'jsonwebtoken';
export const hs = jwt.sign({ sub: 'u1' }, 'test-only-secret', { algorithm: 'HS256' });
export function rs(privateKey) { return jwt.sign({ sub: 'u1' }, privateKey, { algorithm: 'RS256' }); }
