# qx-coverage-suite

One small repo that exercises every kind of crypto pattern Qryptive should detect.
Push it, connect it, scan it (2-3 min), and compare the results against expected_findings.csv.

Supported languages only: Python (.py), Java (.java), Go (.go), JavaScript/TypeScript (.js .mjs .ts).

Covers:
- Import styles: alias, wildcard, relative, cross-module (module read), combined, Java static import
- Expression styles: ternary, lambda, comprehension, walrus, chained call, inline return, default arg
- Key generation: RSA, ECDSA, Ed25519, DSA, DH (Python/Java/Go/JS/TS)
- Key files: rsa_private.pem, rsa_public.pem
- Certificates: server.crt, combined.pem (cert + key)
- Tokens: JWT signed (RS256, HS256, ES256)
- Secrets: Django settings.py SECRET_KEY, hardcoded PEM in code, .env
- Algorithms: MD5/SHA-1/SHA-256/SHA-3, AES-GCM (safe), AES-ECB (weak), 3DES, ChaCha20
- PQC: ML-KEM / ML-DSA (Java BouncyCastle) - quantum-safe

All keys and secrets are TEST values. Use expected_findings.csv for automation assertions.
