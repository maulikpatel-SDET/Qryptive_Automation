"""Relative import: from .keys import make_ec."""
from .keys import make_ec
TOKEN_KEY = make_ec()
