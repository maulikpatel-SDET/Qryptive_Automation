"""Defines make_ec (source of the algorithm)."""
from cryptography.hazmat.primitives.asymmetric import ec
def make_ec():
    return ec.generate_private_key(ec.SECP256R1())
