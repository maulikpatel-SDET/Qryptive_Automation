"""Django settings: SECRET_KEY + MD5 password hasher."""
SECRET_KEY = "django-insecure-0123456789abcdef0123456789abcdef"      # hardcoded secret

PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.MD5PasswordHasher",                 # broken
    "django.contrib.auth.hashers.Argon2PasswordHasher",             # good
]
