"""Alias import: rsa as r."""
from cryptography.hazmat.primitives.asymmetric import rsa as r
key = r.generate_private_key(public_exponent=65537, key_size=2048)
