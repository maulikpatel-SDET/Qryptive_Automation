"""Wildcard import: no module prefix at the call."""
from cryptography.hazmat.primitives.asymmetric.ec import *  # noqa: F403
key = generate_private_key(SECP256R1())  # noqa: F405
