"""Ternary: algorithm chosen on one line."""
from cryptography.hazmat.primitives.asymmetric import ec, rsa
LEGACY = True
key = rsa.generate_private_key(public_exponent=65537, key_size=2048) if LEGACY else ec.generate_private_key(ec.SECP256R1())
