"""Lambda, comprehension, walrus, chained call, default arg in one file."""
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa

make = lambda: rsa.generate_private_key(public_exponent=65537, key_size=2048)   # lambda
keys = [rsa.generate_private_key(public_exponent=65537, key_size=2048) for _ in range(2)]  # comprehension
if (k := rsa.generate_private_key(public_exponent=65537, key_size=2048)):       # walrus
    _ = k.key_size
sig = rsa.generate_private_key(public_exponent=65537, key_size=2048).sign(      # chained
    b"x", padding.PKCS1v15(), hashes.SHA256())

def sign(data, _key=ec.generate_private_key(ec.SECP256R1())):                    # default arg
    return _key.sign(data, ec.ECDSA(hashes.SHA256()))
