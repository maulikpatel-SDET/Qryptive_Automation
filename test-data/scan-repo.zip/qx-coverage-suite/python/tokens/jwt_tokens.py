"""JWT signed tokens: RS256, HS256, ES256."""
import jwt

def rs256(claims, rsa_private_pem):
    return jwt.encode(claims, rsa_private_pem, algorithm="RS256")     # RSA

def hs256(claims):
    return jwt.encode(claims, "test-only-secret", algorithm="HS256")  # HMAC

def es256(claims, ec_private_pem):
    return jwt.encode(claims, ec_private_pem, algorithm="ES256")     # ECDSA
