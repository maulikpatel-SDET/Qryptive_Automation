"""Module read: imports make_rsa from another module and calls it."""
from lib.crypto_helper import make_rsa
PAYMENT_KEY = make_rsa(3072)
