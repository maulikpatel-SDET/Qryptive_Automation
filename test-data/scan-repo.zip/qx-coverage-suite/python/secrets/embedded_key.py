"""Private key hardcoded as a string in source (secret exposure)."""
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

WEBHOOK_KEY_PEM = """-----BEGIN PRIVATE KEY-----
MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgWxn0/t0+nDGO2wu2
M3hUx0lghie1SbvSClftI9tF6uihRANCAASMmZZFD+rhIz5/oDVvZwYyOc08uhY7
IbDwX5Wd+F2/5Du76LoH5U3S+pjS56HVa1QuYK81sLZ1wtfiSJ3TOxnt
-----END PRIVATE KEY-----
"""


def sign(body: bytes) -> bytes:
    key = serialization.load_pem_private_key(WEBHOOK_KEY_PEM.encode(), password=None)
    return key.sign(body, ec.ECDSA(hashes.SHA256()))
