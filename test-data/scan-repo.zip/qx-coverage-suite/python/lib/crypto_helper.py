"""Cross-module helper: defines make_rsa."""
from cryptography.hazmat.primitives.asymmetric import rsa
def make_rsa(bits=2048):
    return rsa.generate_private_key(public_exponent=65537, key_size=bits)
