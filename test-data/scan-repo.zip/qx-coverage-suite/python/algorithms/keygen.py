"""Key generation: RSA, ECDSA, Ed25519, DSA, DH."""
from cryptography.hazmat.primitives.asymmetric import dh, dsa, ec, ed25519, rsa

rsa_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)   # RSA
ec_key = ec.generate_private_key(ec.SECP256R1())                           # ECDSA P-256
ed_key = ed25519.Ed25519PrivateKey.generate()                             # Ed25519
dsa_key = dsa.generate_private_key(key_size=2048)                         # DSA
dh_params = dh.generate_parameters(generator=2, key_size=2048)           # DH
