"""Ciphers: AES-GCM (safe), AES-ECB (weak), 3DES, ChaCha20."""
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.decrepit.ciphers.algorithms import TripleDES

gcm = AESGCM(AESGCM.generate_key(256)).encrypt(os.urandom(12), b"x", None)          # AES-256-GCM safe
ecb = Cipher(algorithms.AES(os.urandom(16)), modes.ECB()).encryptor()               # AES-ECB weak
des = Cipher(TripleDES(os.urandom(24)), modes.CBC(os.urandom(8))).encryptor()       # 3DES
chacha = ChaCha20Poly1305(ChaCha20Poly1305.generate_key()).encrypt(os.urandom(12), b"x", None)  # ChaCha20 safe
