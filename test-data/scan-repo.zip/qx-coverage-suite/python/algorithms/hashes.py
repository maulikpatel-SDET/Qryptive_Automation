"""Hashes: MD5, SHA-1, SHA-256, SHA-3."""
import hashlib
md5 = hashlib.md5(b"x").hexdigest()          # broken
sha1 = hashlib.sha1(b"x").hexdigest()        # weak
sha256 = hashlib.sha256(b"x").hexdigest()    # ok
sha3 = hashlib.sha3_256(b"x").hexdigest()    # safe
