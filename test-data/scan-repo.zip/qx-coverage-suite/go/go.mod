module github.com/your-org/qx-coverage-suite/go

go 1.24
