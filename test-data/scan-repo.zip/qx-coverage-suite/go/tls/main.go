// TLS client with verification off and TLS 1.0 (weak).
package main

import (
	"crypto/tls"
	"net/http"
)

func main() {
	tr := &http.Transport{TLSClientConfig: &tls.Config{
		InsecureSkipVerify: true,
		MinVersion:         tls.VersionTLS10,
		CipherSuites:       []uint16{tls.TLS_RSA_WITH_AES_128_CBC_SHA},
	}}
	_, _ = (&http.Client{Transport: tr}).Get("https://example.com")
}
