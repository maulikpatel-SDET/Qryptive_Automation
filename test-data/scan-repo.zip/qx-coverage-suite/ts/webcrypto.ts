// WebCrypto: ECDSA P-256 and RSA-OAEP.
export async function makeKeys(): Promise<CryptoKeyPair[]> {
  const sign = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const wrap = await crypto.subtle.generateKey(
    { name: 'RSA-OAEP', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' },
    true, ['encrypt', 'decrypt']);
  return [sign as CryptoKeyPair, wrap as CryptoKeyPair];
}
