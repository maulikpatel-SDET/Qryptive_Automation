#!/usr/bin/env bash
# Usage: ./push_repo.sh <github-org-or-user>
set -e
ORG="$1"
cd qx-coverage-suite
git init -q && git branch -M main && git remote add origin "https://github.com/$ORG/qx-coverage-suite.git"
git add -A && git commit -qm "Qryptive coverage suite" && git push -u origin main
